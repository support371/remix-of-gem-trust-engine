# GEM Cybersecurity Internal App Service Specification

This document captures the actionable blueprint for building an internal application via Lovable’s development assistant under **encryption mode**. It aligns with enterprise‑grade standards for security, performance and credibility and can be fed directly into Lovable’s chat bar to generate an app consistent with the GEM Cybersecurity & Monitoring Assist brand.

## 🎯 Objectives

- **Centralise Internal Functions:** Consolidate threat monitoring, incident response and compliance management into a single secure interface.
- **Ensure Data Confidentiality:** Operate under Lovable’s encryption mode — all secrets and API keys stored using Lovable’s secret storage. Use Edge Functions to proxy calls to external services without exposing credentials.
- **Accelerate Development:** Leverage the pre‑built Next.js components (Hero, Services, Testimonials, ContactForm, Navigation, Footer, EmergencySection) to assemble a unified experience. Maintain pixel‑perfect responsiveness and match or exceed current production quality.

## 📦 Composition

- **Framework:** Next.js 14+ with App Router, TypeScript, Tailwind CSS, deployed on Vercel.
- **UI Components:**
  - *Navigation* – sticky header with responsive menu and call‑to‑action.
  - *Hero* – light‑themed introduction with CTA buttons and SOC dashboard mockup.
  - *Services* – three card grid outlining monitoring, incident response and compliance services.
  - *Testimonials* – social proof and KPI stats bar with count‑up animation.
  - *ContactForm* – validated lead capture form with success/error states.
  - *EmergencySection* – dark‑themed urgent response banner with call/email CTAs.
  - *Footer* – dark‑themed footer with links, contact info and social icons.

- **Backend Route:** `/api/lead` server action to persist leads. Validate inputs server‑side, call external CRM or database via a secure API key stored in Lovable secrets.

- **Metrics Source of Truth:** Store real stats (e.g., average response time, detection accuracy) in a constants file and reference them across components. Remove any placeholder values to maintain credibility.

## 🔒 Security & Encryption Mode

- **Secrets Management:** Never hard‑code API keys in the frontend. Use Lovable’s secret storage to hold credentials (e.g., CRM API key, analytics token). Describe to Lovable: “Store the CRM API key in secret storage and reference it in an Edge Function.”

- **Edge Functions:** Create Edge Functions for any call requiring secrets. For example, the contact form should call an Edge Function that reads the CRM API key from secrets and submits the lead.

- **Role‑Level Security (RLS):** If using a database, define RLS policies so only authorised employees or services can read/write internal data. Lovable can scaffold these policies when asked.

- **Encryption in Transit:** Ensure TLS is enforced across all endpoints. In Lovable, specify that the app should require HTTPS and reject insecure requests.

- **Security Scanning & Review:** Request Lovable to run an on‑demand security review after building the app to detect common vulnerabilities (XSS, SQL injection, input sanitisation). Address any critical findings before internal deployment.

## 🛠️ Implementation Steps for Lovable Chat

1. **Project Setup:**
   - “Create a new Next.js project with App Router, TypeScript and Tailwind CSS under encryption mode.”
   - “Set the brand colours and typography according to GEM’s palette: white, navy, light‑gray, medium‑gray, dark‑navy and accent colours (electric‑blue, success‑green, alert‑red).”

2. **Assemble the UI:**
   - “Add the pre‑built components (Navigation, Hero, Services, Testimonials, EmergencySection, ContactForm, Footer) into `app/page.tsx` in the order listed to create a cohesive landing flow.”
   - “Ensure each anchor target exists (`#services`, `#contact`, `#emergency`, etc.) and provide placeholder sections for `#about` and `#case‑studies`.”

3. **Lead Capture Backend:**
   - “Generate an Edge Function at `app/api/lead/route.ts` that accepts POST requests. Validate work email, company name and selected service. Use the CRM API key from secret storage to send the lead to our CRM. Return a success JSON payload.”
   - “Update the ContactForm component to submit via fetch to `/api/lead` and handle success/error responses.”

4. **Metrics & Credibility:**
   - “Create `lib/metrics.ts` to store authoritative numbers (e.g., responseTime = 2, detectionAccuracy = 99.97, customersProtected = 500). Import these in Hero and Testimonials sections. Remove any placeholders.”

5. **Security Hardening:**
   - “Enforce CSP, HSTS, X‑Frame‑Options and Referrer‑Policy headers via Next.js middleware. Add input sanitisation on all server functions.”
   - “Rate‑limit `/api/lead` and throttle repeated form submissions.”
   - “Implement bot/spam protection (e.g., honeypot field or CAPTCHA) on ContactForm.”

6. **Monitoring & Analytics:**
   - “Insert metadata in `app/layout.tsx` for SEO (title, description, OpenGraph tags).”
   - “Add analytics events for CTA clicks, form starts and form submissions using a privacy‑compliant service.”

7. **Test & Review:**
   - “Run the app locally and use Lovable’s on‑demand security review to identify vulnerabilities.”
   - “Ensure all CTAs, links and forms behave correctly on mobile, tablet and desktop breakpoints.”

## 📈 Forward‑Looking Enhancements

- **User Authentication:** When the app expands beyond marketing to internal dashboards, integrate SSO (e.g., SAML/SCIM) using Lovable’s authentication providers.
- **Persistent Data Store:** Connect to a secure database with RLS policies to store incident reports, SOC logs and compliance documents. Use row‑level policies to restrict access based on user role.
- **Real‑Time Notifications:** Implement WebSocket or Server‑Sent Events (SSE) via Lovable Edge Functions to push live alerts to analysts.

---

By following this specification inside Lovable’s chat bar, you’ll generate a secure, enterprise‑ready internal app that adheres to GEM Cybersecurity’s brand and security posture while leveraging Lovable’s encryption mode and API capabilities.