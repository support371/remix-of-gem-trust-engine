"use client";

import React, { useState } from "react";
import { Loader2, CheckCircle, Lock } from "lucide-react";

/**
 * Contact Form Section
 *
 * Allows potential clients to request a free security assessment. The form
 * collects a work email, company name and the type of help requested. It
 * enforces validation rules to ensure a company email is used and displays
 * appropriate error or success messages. A loading spinner is shown while
 * submitting the form. On success, a confirmation message replaces the
 * submit button.
 */

interface FormData {
  email: string;
  company: string;
  service: string;
}

interface FormErrors {
  email?: string;
  company?: string;
  service?: string;
  general?: string;
}

interface ContactFormProps {
  onSubmit?: (data: FormData) => Promise<void>;
}

export default function ContactForm({ onSubmit }: ContactFormProps) {
  // Form state
  const [formData, setFormData] = useState<FormData>({
    email: "",
    company: "",
    service: "",
  });
  // Validation errors
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Helper to validate company email addresses
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^@]+@(?!gmail|yahoo|hotmail|outlook)[^@]+\.[^@]+$/i;
    return emailRegex.test(email);
  };

  // Handle input changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error when user edits field
    setErrors((prev) => ({ ...prev, [name]: undefined, general: undefined }));
  };

  // Form submission handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: FormErrors = {};
    // Validate email
    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!validateEmail(formData.email)) {
      newErrors.email = "Please use your company email";
    }
    // Validate company
    if (!formData.company) {
      newErrors.company = "Company name is required";
    }
    // Validate service selection
    if (!formData.service) {
      newErrors.service = "Please select an option";
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      return;
    }
    try {
      setIsSubmitting(true);
      // Invoke optional external submit handler
      if (onSubmit) {
        await onSubmit(formData);
      } else {
        // Simulate network delay for demonstration
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      setIsSuccess(true);
    } catch (error) {
      setErrors({ general: "An unexpected error occurred. Please try again." });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="bg-white px-6 py-16 sm:py-20" aria-label="Contact Form Section">
      <div className="max-w-screen-md mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-[#0A2463] mb-4">
          Get Your Free Security Assessment
        </h2>
        <p className="text-lg text-[#6B7280] mb-12">
          Schedule a 30‑minute consultation with our security experts. No credit card required.
        </p>
        <div className="bg-white shadow-md rounded-xl p-8 sm:p-12 mx-auto max-w-lg">
          {/* Display success message */}
          {isSuccess ? (
            <div className="bg-[#10B981] text-white p-6 rounded-md">
              <p className="flex items-center justify-center text-lg font-semibold">
                <CheckCircle className="h-6 w-6 mr-2" />
                Thank you! We'll contact you within 24 hours to schedule your assessment.
              </p>
              <p className="mt-2 text-sm">Check your email for confirmation. Average response time: 2 hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              {/* Work email field */}
              <div className="mb-6 text-left">
                <label
                  htmlFor="email"
                  className="block text-sm font-bold text-[#0A2463] mb-2"
                >
                  Work Email*
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="you@company.com"
                  value={formData.email}
                  onChange={handleChange}
                  className={`block w-full h-12 px-4 py-2 rounded-md border ${
                    errors.email ? "border-[#EF4444]" : "border-[#E5E7EB]"
                  } text-base focus:outline-none focus:ring-2 focus:ring-[#00B2FF] focus:border-[#00B2FF] transition-all duration-200`}
                />
                {errors.email ? (
                  <p className="text-xs text-[#EF4444] mt-1">
                    {errors.email}
                  </p>
                ) : (
                  <p className="text-xs text-[#6B7280] mt-1">
                    Please use your company email
                  </p>
                )}
              </div>
              {/* Company name field */}
              <div className="mb-6 text-left">
                <label
                  htmlFor="company"
                  className="block text-sm font-bold text-[#0A2463] mb-2"
                >
                  Company Name*
                </label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  placeholder="Your Company"
                  value={formData.company}
                  onChange={handleChange}
                  className={`block w-full h-12 px-4 py-2 rounded-md border ${
                    errors.company ? "border-[#EF4444]" : "border-[#E5E7EB]"
                  } text-base focus:outline-none focus:ring-2 focus:ring-[#00B2FF] focus:border-[#00B2FF] transition-all duration-200`}
                />
                {errors.company && (
                  <p className="text-xs text-[#EF4444] mt-1">{errors.company}</p>
                )}
              </div>
              {/* Service select field */}
              <div className="mb-6 text-left">
                <label
                  htmlFor="service"
                  className="block text-sm font-bold text-[#0A2463] mb-2"
                >
                  How can we help?*
                </label>
                <select
                  id="service"
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                  className={`block w-full h-12 px-4 py-2 rounded-md border ${
                    errors.service ? "border-[#EF4444]" : "border-[#E5E7EB]"
                  } bg-white text-base focus:outline-none focus:ring-2 focus:ring-[#00B2FF] focus:border-[#00B2FF] transition-all duration-200`}
                >
                  <option value="" disabled>
                    Select one…
                  </option>
                  <option value="monitoring">24/7 Threat Monitoring</option>
                  <option value="incident">Incident Response</option>
                  <option value="compliance">Compliance Support</option>
                  <option value="emergency">Emergency Support</option>
                  <option value="general">General Inquiry</option>
                </select>
                {errors.service && (
                  <p className="text-xs text-[#EF4444] mt-1">{errors.service}</p>
                )}
              </div>
              {/* Privacy note */}
              <p className="flex items-center text-xs text-[#6B7280] mb-8">
                <Lock className="h-4 w-4 mr-1" />
                Your data is encrypted and never shared. SOC 2 Type II certified.
              </p>
              {/* Submit button */}
              {errors.general && (
                <div className="mb-4 bg-[#EF4444]/10 border border-[#EF4444] text-[#B91C1C] p-3 rounded-md text-sm">
                  {errors.general}
                </div>
              )}
              <button
                type="submit"
                disabled={isSubmitting}
                className={`inline-flex items-center justify-center w-full h-14 rounded-md text-white text-lg font-semibold transition-transform duration-200 focus:outline-none focus:ring-4 focus:ring-[#00B2FF]/50 ${
                  isSubmitting
                    ? "bg-[#00B2FF]/60 cursor-not-allowed"
                    : "bg-[#00B2FF] hover:bg-[#0099DD] active:scale-95"
                }`}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Get Free Security Assessment"
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}