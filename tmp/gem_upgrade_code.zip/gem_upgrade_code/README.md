# GEM Cybersecurity Site Upgrade

This archive contains the modular **Next.js (TypeScript)** components and supporting documentation needed to enhance the GEM Cybersecurity public website. These components are production‑ready and match the professional polish of the existing site, while fixing critical conversion issues.

## Contents

* `components/` – Directory housing React components (`.tsx` files) using Tailwind CSS. Each component is self‑contained and includes comments on purpose, major sections, and state management.
  * `Hero.tsx` – Hero section with CTA buttons and a SOC dashboard mockup.
  * `Services.tsx` – Services showcase with three core offerings.
  * `Testimonials.tsx` – Testimonials and KPI stats bar.
  * `ContactForm.tsx` – Validated contact form with success/error states.
  * `Navigation.tsx` – Responsive header with mobile slide‑in menu.
  * `Footer.tsx` – Footer with links, contact info and social icons.
  * `EmergencySection.tsx` – Urgent response banner for incidents.

* `gem_internal_app_spec.md` – Specification for an internal, encrypted operations platform built via the Lovable assistant. (Included for reference if you plan to build an internal tool in parallel.)

## Usage

1. Extract the archive and place the `components/` folder into your Next.js project (App Router). Import and compose these components in `app/page.tsx` or another page to build your homepage.
2. Refer to `gem_internal_app_spec.md` if you intend to leverage Lovable to create an encrypted internal app for SOC analysts and administrators.
3. Run your Next.js development server and adjust any styling or content to match your brand guidelines.

## License

Provided for GEM Cybersecurity internal use. Do not distribute externally without permission.